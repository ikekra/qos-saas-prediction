import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { serviceId, testType = 'latency', runCount = 1 } = await req.json();

    if (!serviceId) {
      return new Response(
        JSON.stringify({ error: 'Service ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get service details
    const { data: service, error: serviceError } = await supabaseClient
      .from('services')
      .select('*')
      .eq('id', serviceId)
      .single();

    if (serviceError || !service) {
      return new Response(
        JSON.stringify({ error: 'Service not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const results = [];
    
    // Run multiple tests if requested
    for (let i = 0; i < Math.min(runCount, 10); i++) {
      const startTime = Date.now();
      let latency = 0;
      let throughput = 0;
      let errorRate = 0;
      let successRate = 100;
      let status = 'completed';

      try {
        // Perform latency test
        if (testType === 'latency' || testType === 'load') {
          const response = await fetch(service.base_url, {
            method: 'GET',
            signal: AbortSignal.timeout(10000),
          });

          latency = Date.now() - startTime;
          successRate = response.ok ? 100 : 0;
          errorRate = response.ok ? 0 : 100;
        }

        // Perform throughput test (3 parallel requests)
        if (testType === 'throughput') {
          const requests = Array(3).fill(null).map(() => 
            fetch(service.base_url, {
              method: 'GET',
              signal: AbortSignal.timeout(10000),
            })
          );

          const responses = await Promise.all(requests);
          latency = (Date.now() - startTime) / 3;

          const successCount = responses.filter((r) => r.ok).length;
          successRate = (successCount / 3) * 100;
          errorRate = 100 - successRate;

          // Calculate throughput
          const responseText = await responses[0].text();
          const sizeInBytes = new TextEncoder().encode(responseText).length;
          const sizeInKB = sizeInBytes / 1024;
          const timeInSeconds = (latency * 3) / 1000;
          throughput = sizeInKB / timeInSeconds;
        }

      } catch (error) {
        console.error(`Test ${i + 1} failed:`, error);
        latency = Date.now() - startTime;
        errorRate = 100;
        successRate = 0;
        status = 'failed';
      }

      // Store result
      const { data: testResult, error: insertError } = await supabaseClient
        .from('test_results')
        .insert({
          service_id: serviceId,
          user_id: user.id,
          test_type: testType,
          latency: Math.round(latency),
          throughput: Math.round(throughput * 100) / 100,
          error_rate: Math.round(errorRate),
          success_rate: Math.round(successRate),
          status,
        })
        .select()
        .single();

      if (insertError) {
        console.error('Failed to save test result:', insertError);
      } else {
        results.push(testResult);
      }
    }

    // Calculate aggregates if multiple tests were run
    const avgLatency = results.reduce((sum, r) => sum + r.latency, 0) / results.length;
    const avgThroughput = results.reduce((sum, r) => sum + (r.throughput || 0), 0) / results.length;
    const avgErrorRate = results.reduce((sum, r) => sum + r.error_rate, 0) / results.length;
    const avgSuccessRate = results.reduce((sum, r) => sum + r.success_rate, 0) / results.length;

    return new Response(
      JSON.stringify({
        success: true,
        results,
        aggregate: {
          latency: Math.round(avgLatency),
          throughput: Math.round(avgThroughput * 100) / 100,
          errorRate: Math.round(avgErrorRate),
          successRate: Math.round(avgSuccessRate),
        },
        service: {
          id: service.id,
          name: service.name,
        },
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Test service error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
