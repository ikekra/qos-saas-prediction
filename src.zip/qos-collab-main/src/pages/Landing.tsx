import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BarChart3, Clock, Shield, TrendingUp, Users, Zap, ChevronRight, CheckCircle, Github, Linkedin, Mail, Activity, Globe, Cpu, Star, Lock, Target } from 'lucide-react';
import heroImage from '@/assets/hero-qos-monitoring.jpg';
import testimonial1 from '@/assets/testimonial-1.jpg';
import testimonial2 from '@/assets/testimonial-2.jpg';
import testimonial3 from '@/assets/testimonial-3.jpg';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { ScrollableRow } from '@/components/ScrollableRow';
import { ServiceCard } from '@/components/ServiceCard';
import { ThemeToggle } from '@/components/ThemeToggle';

// Mock data for recent services
const recentServices = [
  { id: 1, serviceName: 'api.example.com', latency: 145, uptime: 99.9, status: 'stable' as const, lastTested: '2 mins ago', trend: 'stable' as const },
  { id: 2, serviceName: 'webapp.demo.io', latency: 289, uptime: 98.5, status: 'degrading' as const, lastTested: '5 mins ago', trend: 'up' as const },
  { id: 3, serviceName: 'service.cloud.net', latency: 98, uptime: 99.7, status: 'stable' as const, lastTested: '10 mins ago', trend: 'down' as const },
  { id: 4, serviceName: 'data.platform.com', latency: 567, uptime: 95.2, status: 'critical' as const, lastTested: '15 mins ago', trend: 'up' as const },
  { id: 5, serviceName: 'auth.service.io', latency: 112, uptime: 99.5, status: 'stable' as const, lastTested: '20 mins ago', trend: 'stable' as const },
];

const topPerformers = [
  { id: 6, serviceName: 'cdn.fast.net', latency: 45, uptime: 99.99, status: 'stable' as const, lastTested: '1 min ago', trend: 'down' as const },
  { id: 7, serviceName: 'cache.speed.io', latency: 67, uptime: 99.95, status: 'stable' as const, lastTested: '3 mins ago', trend: 'stable' as const },
  { id: 8, serviceName: 'edge.compute.com', latency: 78, uptime: 99.92, status: 'stable' as const, lastTested: '7 mins ago', trend: 'down' as const },
  { id: 9, serviceName: 'api.blazing.dev', latency: 89, uptime: 99.88, status: 'stable' as const, lastTested: '12 mins ago', trend: 'stable' as const },
];

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Landing() {
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleBetaSignup = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Thanks for your interest!",
      description: "We'll contact you soon about early access.",
    });
    setEmail('');
    setName('');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-glass shadow-soft">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">QoSCollab</span>
          </Link>
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Link to="/auth/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link to="/auth/register">
              <Button className="shadow-soft">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section - Netflix Style */}
      <section className="relative overflow-hidden min-h-[90vh] flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="QoS Monitoring"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-transparent" />
        </div>
        <div className="container relative z-10 py-24">
          <motion.div
            className="max-w-2xl space-y-8"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Activity className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">AI-Powered Performance Intelligence</span>
            </motion.div>
            
            <motion.h1
              className="text-5xl font-bold tracking-tight sm:text-6xl md:text-7xl leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Analyze and Optimize{' '}
              <span className="bg-gradient-to-r from-primary via-primary-glow to-accent bg-clip-text text-transparent">
                Web Service Performance
              </span>
            </motion.h1>
            
            <motion.p
              className="text-xl text-muted-foreground leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Empowering developers to measure, visualize, and enhance service quality effortlessly with intelligent factorization analysis
            </motion.p>
            
            <motion.div
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Link to="/auth/register">
                <Button size="lg" className="gap-2 shadow-glow text-lg px-8 h-14">
                  Get Started <ChevronRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/auth/login">
                <Button size="lg" variant="outline" className="text-lg px-8 h-14 backdrop-blur-sm">
                  View Dashboard
                </Button>
              </Link>
            </motion.div>

            {/* Trust Badges */}
            <motion.div
              className="flex flex-wrap gap-6 pt-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4 text-primary" />
                <span>Secure Platform</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Globe className="h-4 w-4 text-primary" />
                <span>24/7 Monitoring</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Cpu className="h-4 w-4 text-primary" />
                <span>AI-Driven Insights</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Recent Services - Netflix Style Scrollable Row */}
      <section className="container py-16">
        <ScrollableRow title="Recently Tested Services">
          {recentServices.map((service) => (
            <ServiceCard key={service.id} {...service} />
          ))}
        </ScrollableRow>
      </section>

      {/* Top Performers Row */}
      <section className="container py-8">
        <ScrollableRow title="Top Performers">
          {topPerformers.map((service) => (
            <ServiceCard key={service.id} {...service} />
          ))}
        </ScrollableRow>
      </section>

      {/* USP Section - Enhanced */}
      <section className="container py-24">
        <motion.div
          className="mx-auto max-w-3xl text-center space-y-6 mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold">Why Choose QoSCollab?</h2>
          <p className="text-xl text-muted-foreground">
            Leverage intelligent factorization to reveal hidden performance issues and gain actionable insights
          </p>
        </motion.div>

        <motion.div
          className="grid gap-6 md:grid-cols-3"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {[
            { icon: Zap, title: 'Fast Analysis', desc: 'Get instant insights into your service performance with real-time monitoring' },
            { icon: BarChart3, title: 'Smart Insights', desc: 'AI-powered factorization reveals patterns and anomalies in your data' },
            { icon: TrendingUp, title: 'Real-Time Monitoring', desc: 'Track performance metrics continuously with automated alerting' }
          ].map((item) => (
            <motion.div
              key={item.title}
              whileHover={{ y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="metric-card border-border/50 h-full">
                <CardHeader>
                  <div className="rounded-lg bg-primary/10 w-fit p-3 mb-4">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Features Section - Enhanced */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <motion.div 
            className="mx-auto max-w-2xl text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold tracking-tight mb-4">
              Powerful Features
            </h2>
            <p className="text-lg text-muted-foreground">
              Everything you need to monitor, test, and optimize your web services
            </p>
          </motion.div>

          <motion.div 
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {[
              { icon: Zap, title: 'Latency Testing', desc: 'Test your APIs with automated performance tests for latency and load' },
              { icon: BarChart3, title: 'Real-Time Metrics', desc: 'Track performance with live dashboards and instant alerts' },
              { icon: Shield, title: 'Performance Reports', desc: 'Generate comprehensive reports with interactive visualizations' },
              { icon: Clock, title: 'API Health', desc: 'Monitor the health of all your APIs in one centralized dashboard' },
              { icon: Users, title: 'Team Collaboration', desc: 'Share results and collaborate seamlessly with your team' },
              { icon: Lock, title: 'Secure Testing', desc: 'Enterprise-grade security with encrypted connections' }
            ].map((feature) => (
              <motion.div key={feature.title} variants={fadeInUp}>
                <Card className="netflix-card border-border/50 h-full">
                  <CardHeader>
                    <div className="rounded-lg bg-primary/10 w-fit p-3 mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                    <CardDescription className="text-base leading-relaxed">
                      {feature.desc}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-background">
        <div className="container">
          <motion.div 
            className="mx-auto max-w-2xl text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-4">Trusted Worldwide</h2>
            <p className="text-lg text-muted-foreground">
              See what developers are saying about QoSCollab
            </p>
          </motion.div>

          <motion.div 
            className="grid gap-8 md:grid-cols-3"
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {[
              { img: testimonial1, name: 'Sarah Johnson', role: 'Product Manager at TechCorp', quote: 'Improved our API uptime tracking by 40%. The insights are invaluable!' },
              { img: testimonial2, name: 'Michael Chen', role: 'Lead Developer at StartupXYZ', quote: 'Best tool for QoS analysis we\'ve found. Simple, fast, and insightful.' },
              { img: testimonial3, name: 'Priya Patel', role: 'Director at GlobalTech', quote: 'Helps us maintain 99.9% uptime consistently. Absolutely essential.' }
            ].map((testimonial) => (
              <motion.div key={testimonial.name} variants={fadeInUp}>
                <Card className="metric-card border-border/50 h-full">
                  <CardHeader className="text-center">
                    <img 
                      src={testimonial.img} 
                      alt={testimonial.name}
                      className="w-20 h-20 rounded-full mx-auto mb-4 object-cover ring-4 ring-primary/10"
                    />
                    <div className="flex justify-center mb-3">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                      ))}
                    </div>
                    <CardDescription className="text-base italic mb-4">
                      "{testimonial.quote}"
                    </CardDescription>
                    <CardTitle className="text-base">{testimonial.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </CardHeader>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Join Beta - Enhanced */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <motion.div 
            className="mx-auto max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Card className="metric-card shadow-large border-border/50">
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-3xl mb-2">Join Early Access</CardTitle>
                <CardDescription className="text-base">
                  Be the first to experience new features and shape the future of QoSCollab
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBetaSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" size="lg">
                    Request Early Access
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/50 py-12">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">QoSCollab</span>
              </div>
              <p className="text-sm text-muted-foreground">
                AI-powered performance intelligence for modern web services
              </p>
              <div className="flex gap-3">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Github className="h-4 w-4" />
                  </Button>
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Linkedin className="h-4 w-4" />
                  </Button>
                </a>
                <a href="mailto:contact@qoscollab.com">
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Mail className="h-4 w-4" />
                  </Button>
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/auth/register" className="text-muted-foreground hover:text-primary transition-colors">Get Started</Link></li>
                <li><Link to="/auth/login" className="text-muted-foreground hover:text-primary transition-colors">Dashboard</Link></li>
                <li><a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">About</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Blog</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Careers</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Security</a></li>
              </ul>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} QoSCollab. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
